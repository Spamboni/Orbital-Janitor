# ORBITAL JANITOR

Physics-based mobile game. Drag debris into the red target zone using chain reactions.

---

## Project Structure

```
orbital-janitor/
├── index.html              ← Entry point
├── capacitor.config.json   ← Android/iOS packaging config
├── css/
│   └── styles.css          ← All UI chrome styling
└── js/
    ├── physics.js          ← Pure physics engine (no DOM, no rendering)
    ├── objects.js          ← Game entity classes (draw only)
    ├── ui.js               ← Input handling + HUD DOM updates
    └── game.js             ← Game loop, level management, win logic
```

### Module responsibilities

| File | What it owns | What it does NOT touch |
|---|---|---|
| `physics.js` | Gravity, friction, collision math, sparks | DOM, canvas, game state |
| `objects.js` | `PhysObj`, `StaticObstacle`, `TargetZone`, `TargetBarrier` draw methods | Physics, DOM |
| `ui.js` | HUD DOM updates, drag/touch input, win overlay | Canvas, physics |
| `game.js` | `requestAnimationFrame` loop, level defs, win detection, rendering | Nothing — coordinates everything else |

---

## Local Development

Just open `index.html` in a browser — no build step required.

```bash
# Optional: use a local server to avoid CORS on some browsers
npx serve .
# or
python3 -m http.server 8080
```

---

## Adding Levels

Edit the `LEVELS` array at the top of `game.js`:

```js
const LEVELS = [
  {
    objects: [
      { x: 160, y: 180, r: 15, mass: 2.0, color: '#1040a0', glow: '#4488ff', label: 'DBR' },
      // ... more objects
    ],
    obstacles: [
      { x: 280, y: 220, shape: 'triangle', size: 32 },
      // shapes: 'triangle' | 'square' | 'hexagon'
    ],
    targetX: 680, targetY: 460, targetR: 32,
    barrierR: 80, barrierThickness: 14, barrierGap: Math.PI * 0.22,
  },
  // add more level objects here...
];
```

---

## Packaging for Android (Capacitor)

### Prerequisites
```bash
npm install -g @capacitor/cli
npm install @capacitor/core @capacitor/android
```

### Steps

```bash
# 1. Initialise Capacitor (one-time)
npx cap init "Orbital Janitor" "com.yourname.orbitaljanitor" --web-dir .

# 2. Add Android platform
npx cap add android

# 3. Copy web assets into the Android project
npx cap sync android

# 4. Open in Android Studio to build / sign
npx cap open android
```

In Android Studio:
- **Build → Generate Signed Bundle / APK** for Play Store upload
- Set `minSdkVersion 22` (Android 5.1+) in `android/app/build.gradle`
- Add your app icon at `android/app/src/main/res/mipmap-*/`

### Optional native plugins

```bash
# Touch haptics (vibration on collision)
npm install @capacitor/haptics
npx cap sync

# Audio (for when you add sounds)
npm install @capacitor/sound
```

Call from `game.js` after a collision:
```js
import { Haptics, ImpactStyle } from '@capacitor/haptics';
await Haptics.impact({ style: ImpactStyle.Light });
```

---

## Play Store checklist

- [ ] Replace `appId` in `capacitor.config.json` with your real package name
- [ ] Add launcher icons (use Android Asset Studio)
- [ ] Add a splash screen image
- [ ] Set `webContentsDebuggingEnabled: false` (already done)
- [ ] Sign APK with your keystore
- [ ] Fill in Play Console store listing (screenshots, description, rating)

---

## Physics tuning reference

All constants are at the top of `js/physics.js` in the `PHYSICS` object:

| Constant | Default | Effect |
|---|---|---|
| `GRAVITY` | 0.38 | Downward pull per frame |
| `FRICTION` | 0.982 | Velocity decay per frame (1 = no friction) |
| `BOUNCE` | 0.68 | Wall / obstacle elasticity (1 = perfectly elastic) |
| `RESTITUTION` | 0.88 | Object-to-object collision energy retention |
| `DRAG_SCALE` | 14 | Fling speed multiplier |
| `DRAG_DAMPEN` | 0.6 | Fling speed reduction factor |
